@extends('layout.header')

@section('iniheader')
<div class="iniheader">
 <div class="container">
     <h1>Ubah Data Produk</h1>
     @foreach($produk as $p)
<form action="/produk/store" method="post" role="form">
    {{ csrf_field() }}
    
      <div class="box-body">
          
        <div class="form-group">
          <input type="hidden" name="id_produk" value="{{ $p->id_produk }}"> <br/>
          <label for="nama_produk">Nama Produk</label>
          <input type="text" class="form-control" name="nama_produk" id="nama_produk"  value="{{ $p->nama_produk }}">
        </div>
                     
        <div class="form-group">
          <label for="keterangan">Keterangan</label>
          <input type="text" class="form-control" id="keterangan" name="keterangan"  value="{{ $p->keterangan }}">
        </div>                               
        <div class="form-group">
          <label for="harga">Harga</label>
        <input type="text" class="form-control" id="harga" name="harga"  value="{{ $p->harga }}">
        </div>
        <div class="form-group">
          <label for="jumlah">Jumlah</label>
          <input type="text" class="form-control" id="jumlah" name="jumlah"  value="{{ $p->jumlah }}">
        </div>
             
        @endforeach
       
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>

      @endsection