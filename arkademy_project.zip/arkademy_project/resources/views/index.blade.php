@extends('layout.header')

@section('initemplate')
<div class="initemplate">
   
  
    <h1>Hello, Arkademy!</h1>
    <a href="/produk/tambah"> Tambah Data</a>
    <table class="table">
        <thead class="thead-dark">
          <tr>
            {{-- <th scope="col">No</th> --}}
            <th scope="col">Nama Produk</th>
            <th scope="col">Keterangan</th>
            <th scope="col">Harga</th>
            <th scope="col">Jumlah</th>
            <th scope="col">Opsi</th>
          </tr>
        </thead>
        <tbody>
            @foreach($produk as $p)
          <tr>
            {{-- <th scope="row">1</th> --}}
            <td>{{$p->nama_produk}}</td>
            <td>{{$p->keterangan}}</td>
            <td>{{$p->harga}}</td>
            <td>{{$p->jumlah}}</td>
            <td>
                <a href="/produk/edit/{{$p->id_produk}}">Edit</a>
				
				<a href="/produk/hapus/{{$p->id_produk}}">Hapus</a>
            </td>
          </tr>   
          @endforeach      
        </tbody>
      </table>
      
     

   