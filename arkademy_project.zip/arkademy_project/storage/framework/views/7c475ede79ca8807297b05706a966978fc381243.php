<?php $__env->startSection('iniheader'); ?>
<div class="iniheader">
 <div class="container">
     <h1>Tambah Data Produk</h1>
<form action="/produk/store" method="post" role="form">
    <?php echo e(csrf_field()); ?>

    
      <div class="box-body">
          
        <div class="form-group">
          
          <label for="nama_produk">Nama Produk</label>
          <input type="text" class="form-control" name="nama_produk" id="nama_produk">
        </div>
                     
        <div class="form-group">
          <label for="keterangan">Keterangan</label>
          <input type="text" class="form-control" id="keterangan" name="keterangan" >
        </div>                               
        <div class="form-group">
          <label for="harga">Harga</label>
        <input type="text" class="form-control" id="harga" name="harga">
        </div>
        <div class="form-group">
          <label for="jumlah">Jumlah</label>
          <input type="text" class="form-control" id="jumlah" name="jumlah" >
        </div>
             
        
       
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>

      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arkademy_project\resources\views/tambahData.blade.php ENDPATH**/ ?>