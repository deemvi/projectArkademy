<?php $__env->startSection('initemplate'); ?>
<div class="initemplate">
   
  
    <h1>Hello, Arkademy!</h1>
    <a href="/produk/tambah"> Tambah Data</a>
    <table class="table">
        <thead class="thead-dark">
          <tr>
            
            <th scope="col">Nama Produk</th>
            <th scope="col">Keterangan</th>
            <th scope="col">Harga</th>
            <th scope="col">Jumlah</th>
            <th scope="col">Opsi</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            
            <td><?php echo e($p->nama_produk); ?></td>
            <td><?php echo e($p->keterangan); ?></td>
            <td><?php echo e($p->harga); ?></td>
            <td><?php echo e($p->jumlah); ?></td>
            <td>
                <a href="/produk/edit/<?php echo e($p->id_produk); ?>">Edit</a>
				
				<a href="/produk/hapus/<?php echo e($p->id_produk); ?>">Hapus</a>
            </td>
          </tr>   
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
        </tbody>
      </table>
      
     

   
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arkademy_project\resources\views/index.blade.php ENDPATH**/ ?>