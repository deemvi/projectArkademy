<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/','dashboardController@index');
Route::get('/produk/tambah','dashboardController@tambah');
Route::post('/produk/store','dashboardController@store');
Route::get('/produk/edit/{id_produk}','dashboardController@edit');
Route::post('/produk/edit','dashboardController@update');
Route::get('/produk/hapus/{id_produk}','dashboardController@hapus');
