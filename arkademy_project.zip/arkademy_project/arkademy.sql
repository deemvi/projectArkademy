﻿# Host: localhost  (Version 5.5.5-10.4.6-MariaDB)
# Date: 2020-10-09 20:28:51
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "produk"
#

DROP TABLE IF EXISTS `produk`;
CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_produk` varchar(35) DEFAULT NULL,
  `keterangan` varchar(35) DEFAULT NULL,
  `harga` varchar(35) DEFAULT NULL,
  `jumlah` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`id_produk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "produk"
#

INSERT INTO `produk` VALUES (1,'jajanan','uu','20.000','9000'),(3,'Oreo','Makanan','7.500','9');
